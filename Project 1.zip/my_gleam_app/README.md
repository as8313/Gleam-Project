# my_gleam_app

[![Package Version](https://img.shields.io/hexpm/v/my_gleam_app)](https://hex.pm/packages/my_gleam_app)
[![Hex Docs](https://img.shields.io/badge/hex-docs-ffaff3)](https://hexdocs.pm/my_gleam_app/)

```sh
gleam add my_gleam_app@1
```
```gleam
import my_gleam_app

pub fn main() -> Nil {
  // TODO: An example of the project in use
}
```

Further documentation can be found at <https://hexdocs.pm/my_gleam_app>.

## Development

```sh
gleam run   # Run the project
gleam test  # Run the tests
```
